﻿Partial Class Database6DataSet
End Class

Namespace Database6DataSetTableAdapters

    Partial Public Class CheckoutTableAdapter
    End Class
End Namespace
