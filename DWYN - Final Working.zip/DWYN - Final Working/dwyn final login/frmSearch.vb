﻿Public Class frmSearch

    Public Shared strSeries As String

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        'log out link
        Me.Close()
        MessageBox.Show("Logout Successful")
        frmLOGIN.Show()
        frmLOGIN.txtEmail.Focus()
    End Sub


    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click


            txtSearchQuery.Clear()
            DGVResults.Rows.Clear()

    End Sub

    Private Sub Search()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        'Note: Not final product. fields need to be changed A

        'Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        ' Declare Variables

        'Dim NumberOfRows As Integer
        'Dim BookInfo As Object
        'Dim ResourceID As String
        '' Dim MemberID As String = .MemberID
        'Dim MemberIDTest As String = frmLOGIN.memberIDGlobal

        Dim Available As String = "Available"
        Dim NotAvailable As String = "Not Available"
        Dim ResourceID As String
        Dim BookInfo As Object
        Dim NumberOfRows As Integer
        Dim currentdate As Date = Date.Today.Date
        Dim MemberIDTest As String = frmLOGIN.memberIDGlobal
        Dim checkedoutbooks As Integer
        Dim checkedoutbookinfo As Object
        Dim checkoutdate As Object
        Dim RowData As Object    'New addition 
        'Dim strSeries As Object
        'Dim checkoutdate As Integer


        'Dim Results As String
        'NumberOfRows = CheckoutTableAdapter.FillByMemberCheckOut(Database6DataSet.Checkout, MemberIDTest)
        'RowData = LibraryResourcesTableAdapter.GetDataByResourceID(ResourceID)(0)

        If txtSearchQuery.Text = String.Empty Then
            MessageBox.Show("Please enter a book title or author name")
        Else

            ' Clear data grid each time to refresh
            DGVResults.Rows.Clear()

            Dim SearchQuery As String = "%" & txtSearchQuery.Text & "%"

            ' Fill by title
            NumberOfRows = LibraryResourcesTableAdapter.FillBySearchQuery(Database6DataSet.LibraryResources, SearchQuery, SearchQuery, SearchQuery)



            ' If there are any records than perform loop
            If NumberOfRows > 0 Then

                ' Begin a loop that will add the checked out info
                Dim x As Integer = 0
                For x = 0 To NumberOfRows - 1 Step 1

                    RowData = LibraryResourcesTableAdapter.GetDataBySearchQuery(SearchQuery, SearchQuery, SearchQuery)(x)


                    'BookInfo = LibraryResourcesTableAdapter.GetDataBySearchQuery(SearchQuery, SearchQuery, SearchQuery)(x)


                    Dim DueDate As Date

                    ResourceID = RowData.ResourceID
                    BookInfo = CheckoutTableAdapter.GetDataByResourceID(ResourceID)


                    'checkedoutbooks = CheckoutTableAdapter.FillByCheckedOutbooks(LibraryDataSet.CheckOut, ResourceID)
                    'If checkedoutbooks = 1 Then
                    '    checkedoutbookinfo = CheckoutTableAdapter.GetDataByCurrentlyCheckedOut(ResourceID)(0)
                    '    checkoutdate = checkedoutbookinfo.checkoutdate
                    '    DueDate = DateAdd(DateInterval.Day, CheckoutPeriod, checkoutdate)
                    '    Resourcestatus = "Due " & DueDate
                    'Else
                    '    Resourcestatus = "Available"

                    'End If


                    '
                    checkedoutbooks = CheckoutTableAdapter.FillByResourceID(Database6DataSet.Checkout, ResourceID)
                    'checkedoutbooks = CheckoutTableAdapter.FillBycheckedoutbook(Database6DataSet.Checkout, ResourceID)
                    'Dim CheckoutPeriod As Integer
                    If checkedoutbooks > 0 Then
                        'checkedoutbookinfo = CheckoutTableAdapter.GetDataByResourceID(ResourceID)
                        ''If checkedoutbookinfo.ischeckoutdatenull = True Then
                        ''    checkoutdate = Nothing
                        ''Else
                        ''    checkoutdate = checkedoutbookinfo.checkoutdate
                        ''    End If 
                        '    'currentdate = checkedoutbookinfo.checkoutdate
                        'DueDate = DateAdd(DateInterval.Day, CheckoutPeriod, BookInfo.checkoutdate)
                        NotAvailable = "Not Available"
                    Else
                        NotAvailable = "Available"

                    End If


                    'If RowData.IsCheckOutPeriodNull = True Then
                    '    CheckoutPeriod = 14
                    'Else
                    '    CheckoutPeriod = rowdata1.CheckOutPeriod
                    'End If

                    'If RowData.IsSeriesNull = True Then
                    '    strSeries = "None"
                    'Else
                    '    strSeries = RowData.Series
                    'End If
                    'this is the patch, figure it out please


                    ' Add the info to the data grid
                    Dim dgvRow As New DataGridViewRow
                    Dim dgvCell As DataGridViewCell

                    'dgvCell = New DataGridViewTextBoxCell()
                    'dgvCell.Value = strSeries
                    'dgvRow.Cells.Add(dgvCell)

                    ' Add book title to the first column of the DataGridView
                    dgvCell = New DataGridViewTextBoxCell()
                    dgvCell.Value = RowData.title
                    'dgvCell.Value = BookInfo.Title
                    dgvRow.Cells.Add(dgvCell)


                    ' Add author first second column of the DataGridView
                    dgvCell = New DataGridViewTextBoxCell()
                    dgvCell.Value = RowData.authorfirst & " " & RowData.authorlast
                    'dgvCell.Value = BookInfo.AuthorFirst & " " & BookInfo.AuthorLast
                    dgvRow.Cells.Add(dgvCell)

                    ' Add publication date to the third column of the DataGridView
                    dgvCell = New DataGridViewTextBoxCell()
                    dgvCell.Value = RowData.publicationdate

                    dgvRow.Cells.Add(dgvCell)

                    ''Add series to the fourth column of the DataGridView
                    'Dim strSeries As String

                    'If RowData.IsSeriesNull = True Then
                    strSeries = "None"
                    'Else
                    '    'strSeries = RowData.Series
                    'End If

                    dgvCell = New DataGridViewTextBoxCell()
                    dgvCell.Value = strSeries
                    dgvRow.Cells.Add(dgvCell)

                    'dgvCell = New DataGridViewTextBoxCell()
                    'dgvCell.Value = BookInfo.ISBN
                    'dgvRow.Cells.Add(dgvCell)



                    ' Add Resource ID to the fifth column of the DataGridView
                    dgvCell = New DataGridViewTextBoxCell()
                    dgvCell.Value = ResourceID
                    dgvRow.Cells.Add(dgvCell)

                    dgvCell = New DataGridViewTextBoxCell()
                    dgvCell.Value = NotAvailable
                    dgvRow.Cells.Add(dgvCell)


                    DGVResults.Rows.Add(dgvRow)

                Next
                ' Otherwise if there are no books, let user know
            ElseIf NumberOfRows = 0 Then
                MessageBox.Show("Sorry, there are no books that meet your search criteria.")
            End If
        End If

    End Sub

    'Br

    'Sub BookSearch()
    'Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

    '    'Dim SearchQuery As Object = "%" & txtSearchQuery.Text & "%"
    '    Dim SearchQuery As String = "%" & txtSearchQuery.Text & "%"
    '    Dim NumberOfRows As Integer
    '    Dim rowdata1 As Object
    '    Dim resourceid As String
    '    Dim CheckoutPeriod As Long
    '    Dim Resourcestatus As String
    '    Dim strSeries As String
    '    Dim checkoutdate As Date
    '    Dim DueDate As Date
    '    Dim checkedoutbooks As String
    '    Dim checkedoutbookinfo As Object
    '    Dim MemberIDTest As String = frmLOGIN.memberIDGlobal
    '    'Dim bookinfo As Object



    '    DGVResults.Rows.Clear()

    '    'NumberOfRows = LibraryResourcesTableAdapter.FillBySearchQuery(Database6DataSet.Resource, SearchQuery, SearchQuery, SearchQuery)
    '    NumberOfRows = CheckoutTableAdapter.FillByMemberCheckOut(Database6DataSet.Checkout, MemberIDTest)
    '    If NumberOfRows > 0 Then

    '        Dim x As Integer = 0
    '        For x = 0 To NumberOfRows - 1 Step 1

    '            rowdata1 = LibraryResourcesTableAdapter.GetDataBySearchQuery(SearchQuery, SearchQuery, SearchQuery)(x)
    '            resourceid = rowdata1.resourceID
    '            'resourceid = bookinfo.resourceID
    '            If rowdata1.IsCheckOutPeriodNull = True Then
    '                CheckoutPeriod = 14
    '            Else
    '                CheckoutPeriod = rowdata1.CheckOutPeriod
    '            End If

    '            If rowdata1.IsSeriesNull = True Then
    '                strSeries = "None"
    '            Else
    '                strSeries = rowdata1.Series
    '            End If

    '            'rowdata1 = ResourceTableAdapter.GetDataByTitleAuthorLastSeriesISBN(keySearch, keySearch, keySearch, keySearch)(x)
    '            'resourceid = rowdata1.resourceID
    '            CheckoutPeriod = rowdata1.checkoutperiod()
    '            checkedoutbooks = CheckoutTableAdapter.FillBycheckedoutbook(Database6DataSet.Checkout, resourceid)

    '            If checkedoutbooks = 1 Then
    '                checkedoutbookinfo = CheckoutTableAdapter.GetDataBycheckedoutbook(resourceid)(0)
    '                'checkoutdate = checkedoutbookinfo.checkoutdate
    '                DueDate = DateAdd(DateInterval.Day, CheckoutPeriod, checkoutdate)
    '                Resourcestatus = "Due " & DueDate
    '            Else
    '                Resourcestatus = "Available"

    '            End If
    '            Dim dgvRow As New DataGridViewRow
    '            Dim dgvCell As DataGridViewCell


    '            If rowdata1.IsCheckOutPeriodNull = True Then
    '                CheckoutPeriod = 14
    '            Else
    '                CheckoutPeriod = rowdata1.CheckOutPeriod
    '            End If

    '            If rowdata1.IsSeriesNull = True Then
    '                strSeries = "None"
    '            Else
    '                strSeries = rowdata1.Series
    '            End If




    '            dgvCell = New DataGridViewTextBoxCell()
    '            dgvCell.Value = rowdata1.title
    '            dgvRow.Cells.Add(dgvCell)

    '            dgvCell = New DataGridViewTextBoxCell()
    '            dgvCell.Value = rowdata1.authorlast & " " & rowdata1.authorfirst
    '            dgvRow.Cells.Add(dgvCell)

    '            'dgvCell = New DataGridViewTextBoxCell()
    '            'dgvCell.Value = rowdata1.authorfirst
    '            'dgvRow.Cells.Add(dgvCell)

    '            dgvCell = New DataGridViewTextBoxCell()
    '            dgvCell.Value = rowdata1.publicationdate
    '            dgvRow.Cells.Add(dgvCell)

    '            dgvCell = New DataGridViewTextBoxCell()
    '            dgvCell.Value = rowdata1.Series
    '            dgvRow.Cells.Add(dgvCell)

    '            'dgvCell = New DataGridViewTextBoxCell()
    '            'dgvCell.Value = rowdata1.ISBN
    '            'dgvRow.Cells.Add(dgvCell)

    '            'dgvCell = New DataGridViewTextBoxCell()
    '            'dgvCell.Value = rowdata1.genre1
    '            'dgvRow.Cells.Add(dgvCell)

    '            dgvCell = New DataGridViewTextBoxCell()
    '            dgvCell.Value = rowdata1.resourceID
    '            dgvRow.Cells.Add(dgvCell)


    '            'dgvCell = New DataGridViewTextBoxCell()
    '            'dgvCell.Value = checkoutdate
    '            'dgvRow.Cells.Add(dgvCell)

    '            dgvCell = New DataGridViewTextBoxCell()
    '            dgvCell.Value = Resourcestatus
    '            dgvRow.Cells.Add(dgvCell)

    '            DGVResults.Rows.Add(dgvRow)

    '        Next
    '    ElseIf NumberOfRows = 0 Then
    '        MessageBox.Show("No results matching your search were found. Please try again.")
    '    End If


    'End Sub

    '' loading of the search form
    '    radioTitle.Checked = True
    ''btnCheckOut.Enabled = False
    '    DGVResults.Rows.Clear()
    '    txtTitle.Focus()
    ''frmSearch.RefreshTable()


    'End Sub

    Private Sub btnCheckOut_Click(sender As Object, e As EventArgs) Handles btnCheckOut.Click
        If frmLOGIN.verify = 2 Then
            'btnCheckOut.Enabled = False
            'btnCheckOut.Hide()

        ElseIf frmLOGIN.verify = 1 Then
            ' add variables
            Dim ResourceID As String
            Dim CheckOutDate As Date
            Dim MemberID As String = frmLOGIN.memberIDGlobal

            'checkout selected row

            ResourceID = DGVResults.SelectedCells(4).Value

            CheckOutDate = Date.Today
            If DGVResults.SelectedCells(5).Value = "Available" Then

                CheckoutTableAdapter.InsertCheckOut(ResourceID, MemberID, CheckOutDate)


                MessageBox.Show("Checkout Successful! Please view your account to see checked out items.")
                DGVResults.SelectedCells(5).Value = "not available"

            Else
                MessageBox.Show("this book is not available, please select another.")
            End If

            'frmMemberAccount.RefreshTable()


        End If
    End Sub

    Private Sub btnMemberAccount_Click(sender As Object, e As EventArgs) Handles btnMemberAccount.Click


        frmMSGctrl.Show()
        frmMSGctrl.Show_msg("Hi", "How is it going?", frmMSGctrl.MessageType.Information)




        If frmLOGIN.verify = 1 Then
            Me.Close()
            frmMemberAccount.Show()
            frmMemberAccount.RefreshTable()

        ElseIf frmLOGIN.verify = 2 Then
            frmMemberAccount.Hide()
        End If
    End Sub



    Private Sub newResource_Click(sender As Object, e As EventArgs) Handles btnNewResource.Click
        Me.Hide()
        frmNewResource.Show()







    End Sub

    Private Sub txtSearchQuery_TextChanged(sender As Object, e As EventArgs) Handles txtSearchQuery.TextChanged

    End Sub


End Class

