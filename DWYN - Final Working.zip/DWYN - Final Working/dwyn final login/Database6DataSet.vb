﻿Partial Class Database6DataSet
    Partial Class LibraryResourcesDataTable

        Private Sub LibraryResourcesDataTable_ColumnChanging(sender As Object, e As DataColumnChangeEventArgs) Handles Me.ColumnChanging
            If (e.Column.ColumnName = Me.ResourceIDColumn.ColumnName) Then
                'Add user code here
            End If

        End Sub

    End Class

End Class

Namespace Database6DataSetTableAdapters

    Partial Public Class CheckoutTableAdapter
    End Class
End Namespace
