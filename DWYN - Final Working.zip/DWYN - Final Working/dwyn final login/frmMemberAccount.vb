﻿Public Class frmMemberAccount
    'list of public variables
    Public verify As Object   'added recently Amir 12:38 AM

    Dim RowData As Object
    Dim CheckoutPeriod As Integer

    Dim CheckoutRecord As Integer
    Dim bookinfo As Object
    Dim resourceid As String
    Dim Resourcestatus As String
    Dim DueDate As Date
    Dim checkoutdate As Date
    Dim strSeries As String
    Dim memberId As String = frmLOGIN.memberIDGlobal


    'public loop
    Public Sub RefreshTable()
        Dim MemberIDTest As String = frmLOGIN.memberIDGlobal
        Dim NumberOfRows As Integer = 0
        DGVResults.Rows.Clear()
        'determines the number of books the current member has checked out
        'NumberOfRows = CheckoutTableAdapter.FillByMemberCheckOut(Database6DataSet.Checkout, memberId)
        NumberOfRows = CheckoutTableAdapter.FillByMemberCheckOut(Database6DataSet.Checkout, MemberIDTest)
        'of the memeber has at least one book checked out then

        'loop to check books logged out
        If NumberOfRows > 0 Then
            Dim x As Integer = 0



            For x = 0 To NumberOfRows - 1 Step 1

                bookinfo = CheckoutTableAdapter.GetDataByMemberCheckOut(MemberIDTest)(x)
                resourceid = bookinfo.ResourceID

                'resourceid = bookinfo.resourceID
                RowData = LibraryResourcesTableAdapter.GetDataByResourceID(resourceid)(0)

                checkoutdate = bookinfo.checkoutdate
                'checkoutdate = RowData.checkoutdate
                ' CheckoutPeriod = RowData.checkoutperiod

                DueDate = DateAdd(DateInterval.Day, CheckoutPeriod, checkoutdate)

                Resourcestatus = DueDate.Date
                If RowData.IsCheckOutPeriodNull = True Then
                    CheckoutPeriod = 14
                Else
                    'CheckoutPeriod = RowData.CheckOutPeriod
                    CheckoutPeriod = RowData.CheckOutPeriod
                End If

                'If RowData.IsSeriesNull = True Then
                'vernon added
                'If RowData.IsSeriesNull = True Then
                '    MessageBox.Show("This book has no series")
                '    strSeries = "None"
                'Else
                '    ' strSeries = RowData.Series
                'End If



                Dim dgvRow As New DataGridViewRow
                Dim dgvCell As DataGridViewCell


                dgvCell = New DataGridViewTextBoxCell()
                dgvCell.Value = RowData.title
                dgvRow.Cells.Add(dgvCell)

                dgvCell = New DataGridViewTextBoxCell()
                If RowData.isauthormiddlenull = True Then
                    dgvCell.Value = RowData.authorfirst & " " & RowData.authorlast
                Else
                    dgvCell.Value = RowData.authorfirst & " " & RowData.authormiddle & " " & RowData.authorlast
                End If
                dgvRow.Cells.Add(dgvCell)


                dgvCell = New DataGridViewTextBoxCell()
                dgvCell.Value = RowData.publicationdate
                dgvRow.Cells.Add(dgvCell)


                'dgvCell = New DataGridViewTextBoxCell()
                'dgvCell.Value = strSeries
                'dgvRow.Cells.Add(dgvCell)

                'dgvCell = New DataGridViewTextBoxCell()
                'dgvCell.Value = RowData.Date
                'dgvRow.Cells.Add(dgvCell)

                dgvCell = New DataGridViewTextBoxCell()
                dgvCell.Value = Resourcestatus
                dgvRow.Cells.Add(dgvCell)


                dgvCell = New DataGridViewTextBoxCell()
                dgvCell.Value = CheckoutPeriod
                dgvRow.Cells.Add(dgvCell)

                dgvCell = New DataGridViewTextBoxCell()
                dgvCell.Value = RowData.resourceid
                dgvRow.Cells.Add(dgvCell)



                DGVResults.Rows.Add(dgvRow)
                'Results is the name of the DataGridView Control added to the Form

            Next

        ElseIf NumberOfRows = 0 Then
            If frmLOGIN.verify = 2 Then

            ElseIf frmLOGIN.verify = 1 Then
                MessageBox.Show("You have no items checked at this time")
            End If
        End If
    End Sub

    Private Sub btnCheckedOutItems_Click(sender As Object, e As EventArgs) Handles btnCheckedOutItems.Click
        RefreshTable()
        'Dim MemberIDTest As String = frmLOGIN.memberIDGlobal
        'Dim NumberOfRows As Integer = 0
        'DGVResults.Rows.Clear()
        ''determines the number of books the current member has checked out
        ''NumberOfRows = CheckoutTableAdapter.FillByMemberCheckOut(Database6DataSet.Checkout, memberId)
        'NumberOfRows = CheckoutTableAdapter.FillByMemberCheckOut(Database6DataSet.Checkout, MemberIDTest)
        ''of the memeber has at least one book checked out then


        'If NumberOfRows > 0 Then
        '    Dim x As Integer = 0

        '    For x = 0 To NumberOfRows - 1 Step 1

        '        bookinfo = CheckoutTableAdapter.GetDataByMemberCheckOut(MemberIDTest)(x)
        '        resourceid = bookinfo.resourceID

        '        RowData = LibraryResourcesTableAdapter.GetDataByResourceID(resourceid)(0)

        '        checkoutdate = bookinfo.checkoutdate

        '        ' CheckoutPeriod = RowData.checkoutperiod

        '        DueDate = DateAdd(DateInterval.Day, CheckoutPeriod, checkoutdate)

        '        Resourcestatus = "Due " & DueDate.Date

        '        If RowData.IsCheckOutPeriodNull = True Then
        '            CheckoutPeriod = 14
        '        Else
        '            CheckoutPeriod = RowData.CheckOutPeriod
        '        End If

        '        If RowData.IsSeriesNull = True Then
        '            strSeries = "None"
        '        Else
        '            strSeries = RowData.Series
        '        End If



        '        Dim dgvRow As New DataGridViewRow
        '        Dim dgvCell As DataGridViewCell


        '        dgvCell = New DataGridViewTextBoxCell()
        '        dgvCell.Value = RowData.title
        '        dgvRow.Cells.Add(dgvCell)

        '        dgvCell = New DataGridViewTextBoxCell()
        '        dgvCell.Value = RowData.authorlast
        '        dgvRow.Cells.Add(dgvCell)


        '        dgvCell = New DataGridViewTextBoxCell()
        '        dgvCell.Value = RowData.publicationdate
        '        dgvRow.Cells.Add(dgvCell)


        '        dgvCell = New DataGridViewTextBoxCell()
        '        dgvCell.Value = strSeries
        '        dgvRow.Cells.Add(dgvCell)

        '        'dgvCell = New DataGridViewTextBoxCell()
        '        'dgvCell.Value = RowData.Date
        '        'dgvRow.Cells.Add(dgvCell)

        '        dgvCell = New DataGridViewTextBoxCell()
        '        dgvCell.Value = Resourcestatus
        '        dgvRow.Cells.Add(dgvCell)



        '        dgvCell = New DataGridViewTextBoxCell()
        '        dgvCell.Value = CheckoutPeriod
        '        dgvRow.Cells.Add(dgvCell)

        '        dgvCell = New DataGridViewTextBoxCell()
        '        dgvCell.Value = resourceid
        '        dgvRow.Cells.Add(dgvCell)


        '        DGVResults.Rows.Add(dgvRow)
        '        'Results is the name of the DataGridView Control added to the Form

        '    Next

        'ElseIf NumberOfRows = 0 Then
        '    MessageBox.Show("You have no items checked at this time")
        'End If


    End Sub




    'RENEW BUTTON BELOW

    Private Sub btnRenew_Click(sender As Object, e As EventArgs) Handles btnRenew.Click

        'declarations
        Dim NumberOfRows As Integer = 0
        Dim currentdate As Date = Date.Today.Date
        Dim MemberIDTest As String = frmLOGIN.memberIDGlobal
        'Dim Results As String
        NumberOfRows = CheckoutTableAdapter.FillByMemberCheckOut(Database6DataSet.Checkout, MemberIDTest)



        If NumberOfRows = 0 Then
            MessageBox.Show("You have no items checked out at this time.")
        Else

            If DGVResults.SelectedRows.Count = 0 Then
                MessageBox.Show("Please select the book you wish to renew")
            ElseIf DGVResults.SelectedRows(0).Cells(5).Value = Nothing Then
                MessageBox.Show("No book has been selected")
            Else

                'renew book by altering the due date and updating the record selected in ‘the “results” data grid the numbers in parentheses are the index of the ‘data grid column holding the piece of information needed.
                resourceid = DGVResults.SelectedRows(0).Cells(4).Value

                CheckoutTableAdapter.RenewBookUpdateQuery(currentdate, resourceid)

                'CheckoutPeriod = Results.SelectedCells(6).Value
                CheckoutPeriod = DGVResults.SelectedRows(0).Cells(4).Value
                DueDate = DateAdd(DateInterval.Day, CheckoutPeriod, currentdate)
                Resourcestatus = DueDate.Date
                DGVResults.SelectedRows(0).Cells(4).Value = Resourcestatus
                'DGVResults.SelectedRows(0).Cells(5).Value = currentdate

                MessageBox.Show("you have successfully renewed your book.", " Book Renewal Successful", MessageBoxButtons.OK)
                RefreshTable()
            End If
        End If
    End Sub





    'RETURN BUTTON BELOW

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click

        Dim NumberOfRows As Integer = 0
        Dim ResourceID As String
        Dim CurrentDate As Date
        Dim MemberID As String = frmLOGIN.memberIDGlobal



        '' Store date into Current Date
        CurrentDate = Date.Now


        '' Check to see what books are checked out


        NumberOfRows = CheckoutTableAdapter.FillByMemberCheckOut(Database6DataSet.Checkout, MemberID)


        If NumberOfRows = 0 Then
            MessageBox.Show("No books")

        Else
            If DGVResults.SelectedCells.Count = 0 Then
                MessageBox.Show("Please select book to return")
            Else
                If DGVResults.SelectedCells(5).Value = Nothing Then
                    MessageBox.Show("No book has been selected")
                Else
                    ResourceID = DGVResults.SelectedCells(5).Value.ToString


                    CheckoutTableAdapter.ReturnBookUpdateQuery(CurrentDate, ResourceID)
                    DGVResults.SelectedCells(5).Value = "Returned"

                    MessageBox.Show("Return Successful")
                    RefreshTable()
                End If

            End If
        End If




        ''TO AUTOMATICALLY UPDATE CHECK OUT LIST  
        'DGVResults.Rows.Clear()
        ''determine the number of books the current member has checked out.
        'MemberID = frmLOGIN.memberIDGlobal

        'NumberOfRows = CheckoutTableAdapter.FillByMemberCheckOut(Database6DataSet.Checkout, MemberID)

        'If NumberOfRows > 0 Then

        '    Dim x As Integer = 0
        '    'begin a loop that will add information for each of the currently checked out books one at a time to DataGridView
        '    '         
        '    For x = 0 To NumberOfRows - 1 Step 1

        '        bookinfo = CheckoutTableAdapter.GetDataByMemberCheckOut(MemberID)

        '        'ResourceID = bookinfo.resourceID   'de-commented this 

        '        RowData = LibraryResourcesTableAdapter.GetDataByResourceID(ResourceID)(0)
        '        'calculate the due date for a book based on the check out date and the book’s checkout period.



        '    Next

        'End If
        ''            Next
        ''        ElseIf NumberOfRows = 0 Then
        ''            MessageBox.Show("You have no items checked out at this time.")

        ''        End If


        ''    End If
        ''End If

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        'log out link
        Me.Close()
        MessageBox.Show("Logout Successful")
        frmLOGIN.Show()
        frmLOGIN.txtEmail.Focus()

    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnBookSearch.Click
        'button brings us to search form
        'Show or hide Add New button depending on member / employee status
        If frmLOGIN.verify = 1 Then
            frmSearch.btnNewResource.Visible = False
        ElseIf frmLOGIN.verify = 2 Then
            frmSearch.btnNewResource.Visible = True
            'MessageBox.Show("Adding New Resources is an Employee Priviledge")
        End If
        If frmStaffLogin.verify = 1 Then
            frmSearch.btnCheckOut.Visible = True
        ElseIf frmLOGIN.verify = 2 Then
            frmSearch.btnCheckOut.Visible = False
        End If
        Me.Hide()
        frmSearch.Show()
        frmSearch.txtSearchQuery.Focus()
    End Sub


    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub frmMemberAccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class










