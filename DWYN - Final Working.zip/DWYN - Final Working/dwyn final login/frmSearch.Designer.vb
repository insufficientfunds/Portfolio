﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSearch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSearch))
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.DGVResults = New System.Windows.Forms.DataGridView()
        Me.Title = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Author = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PublicationDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Series = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.clmResourceID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Available = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.FillByEmailToolStrip = New System.Windows.Forms.ToolStrip()
        Me.EmailToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.EmailToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.FillByEmailToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.FillByEmailToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.EmailToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.EmailToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.FillByEmailToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.btnCheckOut = New System.Windows.Forms.Button()
        Me.txtSearchQuery = New System.Windows.Forms.TextBox()
        Me.btnMemberAccount = New System.Windows.Forms.Button()
        Me.lblSearch = New System.Windows.Forms.Label()
        Me.btnNewResource = New System.Windows.Forms.Button()
        Me.Database6DataSet = New DWYN_FINAL_LOGIN.Database6DataSet()
        Me.Database6DataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LibraryResourcesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LibraryResourcesTableAdapter = New DWYN_FINAL_LOGIN.Database6DataSetTableAdapters.LibraryResourcesTableAdapter()
        Me.TableAdapterManager = New DWYN_FINAL_LOGIN.Database6DataSetTableAdapters.TableAdapterManager()
        Me.CheckoutBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CheckoutTableAdapter = New DWYN_FINAL_LOGIN.Database6DataSetTableAdapters.CheckoutTableAdapter()
        Me.EmployeeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EmployeeTableAdapter = New DWYN_FINAL_LOGIN.Database6DataSetTableAdapters.EmployeeTableAdapter()
        Me.LibraryMembersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LibraryMembersTableAdapter = New DWYN_FINAL_LOGIN.Database6DataSetTableAdapters.LibraryMembersTableAdapter()
        Me.Label6 = New System.Windows.Forms.Label()
        CType(Me.DGVResults, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillByEmailToolStrip.SuspendLayout()
        Me.FillByEmailToolStrip1.SuspendLayout()
        CType(Me.Database6DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Database6DataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LibraryResourcesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CheckoutBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LibraryMembersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(533, 152)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(101, 31)
        Me.btnSearch.TabIndex = 1
        Me.btnSearch.Text = "&Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(119, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 13)
        Me.Label1.TabIndex = 2
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Poor Richard", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.LinkColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.LinkLabel1.Location = New System.Drawing.Point(661, 30)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(76, 22)
        Me.LinkLabel1.TabIndex = 3
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Log Out"
        '
        'DGVResults
        '
        Me.DGVResults.AllowUserToOrderColumns = True
        Me.DGVResults.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DGVResults.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.DGVResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVResults.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Title, Me.Author, Me.PublicationDate, Me.Series, Me.clmResourceID, Me.Available})
        Me.DGVResults.GridColor = System.Drawing.SystemColors.ButtonHighlight
        Me.DGVResults.Location = New System.Drawing.Point(89, 216)
        Me.DGVResults.Name = "DGVResults"
        Me.DGVResults.RowHeadersVisible = False
        Me.DGVResults.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DGVResults.Size = New System.Drawing.Size(648, 170)
        Me.DGVResults.TabIndex = 17
        '
        'Title
        '
        Me.Title.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.Title.HeaderText = "Title"
        Me.Title.Name = "Title"
        Me.Title.Width = 52
        '
        'Author
        '
        Me.Author.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.Author.HeaderText = "Author"
        Me.Author.Name = "Author"
        Me.Author.Width = 63
        '
        'PublicationDate
        '
        Me.PublicationDate.FillWeight = 75.0!
        Me.PublicationDate.HeaderText = "Publication Date"
        Me.PublicationDate.Name = "PublicationDate"
        '
        'Series
        '
        Me.Series.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.Series.HeaderText = "Series"
        Me.Series.Name = "Series"
        Me.Series.Width = 61
        '
        'clmResourceID
        '
        Me.clmResourceID.HeaderText = "ResourceId"
        Me.clmResourceID.Name = "clmResourceID"
        '
        'Available
        '
        Me.Available.HeaderText = "Available"
        Me.Available.Name = "Available"
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(89, 435)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(101, 31)
        Me.btnClear.TabIndex = 18
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'FillByEmailToolStrip
        '
        Me.FillByEmailToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EmailToolStripLabel, Me.EmailToolStripTextBox, Me.FillByEmailToolStripButton})
        Me.FillByEmailToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.FillByEmailToolStrip.Name = "FillByEmailToolStrip"
        Me.FillByEmailToolStrip.Size = New System.Drawing.Size(972, 25)
        Me.FillByEmailToolStrip.TabIndex = 40
        Me.FillByEmailToolStrip.Text = "FillByEmailToolStrip"
        Me.FillByEmailToolStrip.Visible = False
        '
        'EmailToolStripLabel
        '
        Me.EmailToolStripLabel.Name = "EmailToolStripLabel"
        Me.EmailToolStripLabel.Size = New System.Drawing.Size(39, 22)
        Me.EmailToolStripLabel.Text = "Email:"
        '
        'EmailToolStripTextBox
        '
        Me.EmailToolStripTextBox.Name = "EmailToolStripTextBox"
        Me.EmailToolStripTextBox.Size = New System.Drawing.Size(100, 25)
        '
        'FillByEmailToolStripButton
        '
        Me.FillByEmailToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillByEmailToolStripButton.Name = "FillByEmailToolStripButton"
        Me.FillByEmailToolStripButton.Size = New System.Drawing.Size(68, 22)
        Me.FillByEmailToolStripButton.Text = "FillByEmail"
        '
        'FillByEmailToolStrip1
        '
        Me.FillByEmailToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EmailToolStripLabel1, Me.EmailToolStripTextBox1, Me.FillByEmailToolStripButton1})
        Me.FillByEmailToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.FillByEmailToolStrip1.Name = "FillByEmailToolStrip1"
        Me.FillByEmailToolStrip1.Size = New System.Drawing.Size(810, 25)
        Me.FillByEmailToolStrip1.TabIndex = 41
        Me.FillByEmailToolStrip1.Text = "FillByEmailToolStrip1"
        Me.FillByEmailToolStrip1.Visible = False
        '
        'EmailToolStripLabel1
        '
        Me.EmailToolStripLabel1.Name = "EmailToolStripLabel1"
        Me.EmailToolStripLabel1.Size = New System.Drawing.Size(39, 22)
        Me.EmailToolStripLabel1.Text = "Email:"
        '
        'EmailToolStripTextBox1
        '
        Me.EmailToolStripTextBox1.Name = "EmailToolStripTextBox1"
        Me.EmailToolStripTextBox1.Size = New System.Drawing.Size(100, 25)
        '
        'FillByEmailToolStripButton1
        '
        Me.FillByEmailToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillByEmailToolStripButton1.Name = "FillByEmailToolStripButton1"
        Me.FillByEmailToolStripButton1.Size = New System.Drawing.Size(68, 22)
        Me.FillByEmailToolStripButton1.Text = "FillByEmail"
        '
        'btnCheckOut
        '
        Me.btnCheckOut.Location = New System.Drawing.Point(636, 435)
        Me.btnCheckOut.Name = "btnCheckOut"
        Me.btnCheckOut.Size = New System.Drawing.Size(101, 31)
        Me.btnCheckOut.TabIndex = 42
        Me.btnCheckOut.Text = "Check Out"
        Me.btnCheckOut.UseVisualStyleBackColor = True
        '
        'txtSearchQuery
        '
        Me.txtSearchQuery.AutoCompleteCustomSource.AddRange(New String() {"When I Found You", "When I Found You", "Unbroken: A World War II Story of Survival, Resilience, and Redemption", "Unbroken: A World War II Story of Survival, Resilience, and Redemption", "Unbroken: A World War II Story of Survival, Resilience, and Redemption", "Ender's Game", "Ender's Game", "Ender's Game", "The Shoemaker's Wife", "The Shoemaker's Wife", "Harry Potter and the Chamber of Secrets", "Harry Potter and the Chamber of Secrets", "Harry Potter and the Goblet of Fire", "Harry Potter and the Goblet of Fire", "All the Light We Cannot See", "Children of the Mind", "Speaker for the Dead", "Harry Potter and the Prisoner of Azkaban", "Harry Potter and the Prisoner of Azkaban", "The Racketeer", "The Racketeer", "Harry Potter and the Sorcerer's Stone", "Harry Potter and the Sorcerer's Stone", "Harry Potter and the sorcerer's stone", "Harry Potter and the Order of the Phoenix", "Harry Potter and the Order of the Phoenix", "8 Reasons Your Life Matters", "The Goldfinch: A Novel ", "The Goldfinch: A Novel ", "The Goldfinch: A Novel ", "What She Left Behind ", "The Husband's Secret", "Defending Jacob", "Defending Jacob", "Drowning Ruth", "New York: The Novel", "Harry Potter and the Half-Blood Prince", "Harry Potter and the Half-Blood Prince", "Harry Potter and the Half-Blood Prince", "The Lightning Thief", "The Lightning Thief", "Orphan Train", "The Book Thief", "The Sea of Monsters", "The Sea of Monsters", "The Orphan Master's Son:", "The Titan's Curse", "The Battle of the Labyrinth", "The Battle of the Labyrinth", "Xenocide", "The Hunger Games", "The Hunger Games", "The Hunger Games", "The Last Olympian", "The Last Olympian", "Catching Fire", "Catching Fire", "Catching Fire", "The Light Between Oceans", "Mockingjay", "Mockingjay", "Mockingjay", "The Invention of Wings", "Harry Potter and the Deathly Hallows", "Harry Potter and the Deathly Hallows", "Harry Potter and the Deathly Hallows", "The Fault in Our Stars", "The Fault in Our Stars", "The Fault in Our Stars", "What Alice Forgot", "And the Mountains Echoed", "Crazy Little Thing ", "Crazy Little Thing ", "Where We Belong ", "The Target ", "The Storyteller", "The Silkworm ", "Sycamore Row", "Gone Girl", "Gone Girl", "Gone Girl", "Gone Girl", "The Kitchen House", "The Kitchen House", "The Kitchen House", "The Rosie Project", "The Rosie Project", "We Are Water", "The Book Thief", "The Book Thief", "The Book Thief", "The Lion, The Lamb, The Hunted ", "Best Kept Secrets", "The Secret History", "Whistling In the Dark", "The Nazi Officer's Wife: How One Jewish Woman Survived the Holocaust ", "The Gods of Guilt ", "Me Before You", "War Brides", "The Language of Flowers", "Wired", "Hopeless", "Inferno", "The Longest Ride", "The Silver Star", "The Cuckoo's Calling ", "Wonder", "Six Years", "The Girl Who Came Home: A Novel of the Titanic ", "The Hit ", "Let's Pretend This Never Happened", "The Time Keeper", "Invisible", "Still Life with Bread Crumbs: A Novel", "Don't Let Me Go", "Big Little Lies", "The Plum Tree ", "Missing You", "Sharp Objects: A Novel", "The Pecan Man", "The Sisterhood"})
        Me.txtSearchQuery.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.txtSearchQuery.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.txtSearchQuery.Location = New System.Drawing.Point(148, 158)
        Me.txtSearchQuery.Name = "txtSearchQuery"
        Me.txtSearchQuery.Size = New System.Drawing.Size(235, 20)
        Me.txtSearchQuery.TabIndex = 43
        '
        'btnMemberAccount
        '
        Me.btnMemberAccount.Location = New System.Drawing.Point(533, 33)
        Me.btnMemberAccount.Name = "btnMemberAccount"
        Me.btnMemberAccount.Size = New System.Drawing.Size(101, 31)
        Me.btnMemberAccount.TabIndex = 44
        Me.btnMemberAccount.Text = "&My Account"
        Me.btnMemberAccount.UseVisualStyleBackColor = True
        '
        'lblSearch
        '
        Me.lblSearch.AutoSize = True
        Me.lblSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSearch.Location = New System.Drawing.Point(144, 129)
        Me.lblSearch.Name = "lblSearch"
        Me.lblSearch.Size = New System.Drawing.Size(195, 20)
        Me.lblSearch.TabIndex = 45
        Me.lblSearch.Text = "Enter Title or Author name"
        '
        'btnNewResource
        '
        Me.btnNewResource.Location = New System.Drawing.Point(533, 91)
        Me.btnNewResource.Name = "btnNewResource"
        Me.btnNewResource.Size = New System.Drawing.Size(101, 31)
        Me.btnNewResource.TabIndex = 46
        Me.btnNewResource.Text = "&Add New"
        Me.btnNewResource.UseVisualStyleBackColor = True
        '
        'Database6DataSet
        '
        Me.Database6DataSet.DataSetName = "Database6DataSet"
        Me.Database6DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Database6DataSetBindingSource
        '
        Me.Database6DataSetBindingSource.DataSource = Me.Database6DataSet
        Me.Database6DataSetBindingSource.Position = 0
        '
        'LibraryResourcesBindingSource
        '
        Me.LibraryResourcesBindingSource.DataMember = "LibraryResources"
        Me.LibraryResourcesBindingSource.DataSource = Me.Database6DataSet
        '
        'LibraryResourcesTableAdapter
        '
        Me.LibraryResourcesTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CheckoutTableAdapter = Nothing
        Me.TableAdapterManager.EmployeeTableAdapter = Nothing
        Me.TableAdapterManager.LibraryMembersTableAdapter = Nothing
        Me.TableAdapterManager.LibraryResourcesTableAdapter = Me.LibraryResourcesTableAdapter
        Me.TableAdapterManager.UpdateOrder = DWYN_FINAL_LOGIN.Database6DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CheckoutBindingSource
        '
        Me.CheckoutBindingSource.DataMember = "Checkout"
        Me.CheckoutBindingSource.DataSource = Me.Database6DataSet
        '
        'CheckoutTableAdapter
        '
        Me.CheckoutTableAdapter.ClearBeforeFill = True
        '
        'EmployeeBindingSource
        '
        Me.EmployeeBindingSource.DataMember = "Employee"
        Me.EmployeeBindingSource.DataSource = Me.Database6DataSet
        '
        'EmployeeTableAdapter
        '
        Me.EmployeeTableAdapter.ClearBeforeFill = True
        '
        'LibraryMembersBindingSource
        '
        Me.LibraryMembersBindingSource.DataMember = "LibraryMembers"
        Me.LibraryMembersBindingSource.DataSource = Me.Database6DataSet
        '
        'LibraryMembersTableAdapter
        '
        Me.LibraryMembersTableAdapter.ClearBeforeFill = True
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Poor Richard", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DarkRed
        Me.Label6.Location = New System.Drawing.Point(79, 46)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(230, 61)
        Me.Label6.TabIndex = 47
        Me.Label6.Text = "DWYN"
        '
        'frmSearch
        '
        Me.AcceptButton = Me.btnSearch
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(810, 573)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnNewResource)
        Me.Controls.Add(Me.lblSearch)
        Me.Controls.Add(Me.btnMemberAccount)
        Me.Controls.Add(Me.txtSearchQuery)
        Me.Controls.Add(Me.btnCheckOut)
        Me.Controls.Add(Me.FillByEmailToolStrip)
        Me.Controls.Add(Me.FillByEmailToolStrip1)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.DGVResults)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnSearch)
        Me.Name = "frmSearch"
        Me.Text = "t "
        CType(Me.DGVResults, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillByEmailToolStrip.ResumeLayout(False)
        Me.FillByEmailToolStrip.PerformLayout()
        Me.FillByEmailToolStrip1.ResumeLayout(False)
        Me.FillByEmailToolStrip1.PerformLayout()
        CType(Me.Database6DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Database6DataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LibraryResourcesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CheckoutBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LibraryMembersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Database6DataSetBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Database6DataSet As DWYN_FINAL_LOGIN.Database6DataSet
    Friend WithEvents DGVResults As System.Windows.Forms.DataGridView
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents LibraryResourcesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents LibraryResourcesTableAdapter As DWYN_FINAL_LOGIN.Database6DataSetTableAdapters.LibraryResourcesTableAdapter
    Friend WithEvents TableAdapterManager As DWYN_FINAL_LOGIN.Database6DataSetTableAdapters.TableAdapterManager
    Friend WithEvents CheckoutBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents CheckoutTableAdapter As DWYN_FINAL_LOGIN.Database6DataSetTableAdapters.CheckoutTableAdapter
    Friend WithEvents EmployeeBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents EmployeeTableAdapter As DWYN_FINAL_LOGIN.Database6DataSetTableAdapters.EmployeeTableAdapter
    Friend WithEvents FillByEmailToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents EmailToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents EmailToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents FillByEmailToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents LibraryMembersBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents LibraryMembersTableAdapter As DWYN_FINAL_LOGIN.Database6DataSetTableAdapters.LibraryMembersTableAdapter
    Friend WithEvents FillByEmailToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents EmailToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents EmailToolStripTextBox1 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents FillByEmailToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents btnCheckOut As System.Windows.Forms.Button
    Friend WithEvents txtSearchQuery As System.Windows.Forms.TextBox
    Friend WithEvents btnMemberAccount As System.Windows.Forms.Button
    Friend WithEvents lblSearch As System.Windows.Forms.Label
    Friend WithEvents btnNewResource As System.Windows.Forms.Button
    Friend WithEvents Title As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Author As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PublicationDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Series As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents clmResourceID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Available As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label6 As System.Windows.Forms.Label
End Class
