﻿Public Class frmStaffLogin

    Public verify As Integer
    Public memberIDGlobal As String

    'Public memberIDGlobal As String


    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        frmMSGctrl.Show()
        frmMSGctrl.Show_msg("Welsome VALUED STAFF MEMBERS!", "Remember to log your holiday hours", frmMSGctrl.MessageType.Notice)


        Dim NumberofRows As Integer

        Dim RowData As Object
        Dim Password As String

        'the following prompts a user to enter an email address and password if submit a blank field
        'PSUEDOCODE: if user enters blank, display message
        If txtEmail.Text = String.Empty Or txtPassword.Text = String.Empty Then
            MessageBox.Show("Please enter valid email and password")

        Else


            NumberofRows = EmployeeTableAdapter.FillByEmail(Database6DataSet.Employee, txtEmail.Text)


            'if data matches a record, go get me a record. The zero indicates that we need to start
            'looking in the very first position in our collection (column 1 row 1). Initial position 0
            If NumberofRows = 1 Then
                RowData = EmployeeTableAdapter.GetDataByEmail(txtEmail.Text)(0)
                Password = RowData.Password 'this line of code grabs the password from our record. Password, our
                'variable, is an assignment statement. Column holds our password


                'Pseudocode: if the entered password matches, show form 2
                If Password = txtPassword.Text Then
                    verify = 2
                    txtEmail.Clear()
                    txtPassword.Clear()

                    frmSearch.Show()
                    Me.Close()
                    frmSearch.btnMemberAccount.Visible = False
                    'MessageBox.Show("LOGIN SUCCESSFUL")
                    ' memberIDGlobal = RowData.Email
                    ' frmMemberAccount.RefreshTable()
                    'frmSearch.Show()

                Else
                    MessageBox.Show("Login Unsuccessful") 'DISPLAY THE MESSAGE IF LOGIN WAS NOT SUCCESSFUL
                    txtPassword.Clear()
                End If
            Else
                MessageBox.Show("No record of this email registered. Please try a different email or register as a new user")

            End If
        End If

        'Hide Checkout Button if employee logs in
        frmSearch.btnCheckOut.Visible = False

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles DWYN.Enter

        Me.DWYN.BackColor = Color.FromArgb(128, 0, 0, 0)

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        MessageBox.Show("Please Enter The Email Address You Used To Register and Associated Password")
    End Sub
End Class