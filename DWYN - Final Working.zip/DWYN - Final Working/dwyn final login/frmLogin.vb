﻿Public Class frmLOGIN

    Public verify As Integer
    Public memberIDGlobal As String

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        'login code

        frmMSGctrl.Show()
        frmMSGctrl.Show_msg("WELCOME!", "Are you a Safeway Member? If so, join the Safeway-Read-A-Thon Today", frmMSGctrl.MessageType.Notice)

        Dim NumberofRows As Integer

        Dim RowData As Object
        Dim Password As String

        'the following prompts a user to enter an email address and password if submit a blank field
        'PSUEDOCODE: if user enters blank, display message
        If txtEmail.Text = String.Empty Or txtPassword.Text = String.Empty Then
            MessageBox.Show("Please enter valid email and password")

        Else


            NumberofRows = LibraryMembersTableAdapter.FillByEmail(Database6DataSet.LibraryMembers, txtEmail.Text)


            'if data matches a record, go get me a record. The zero indicates that we need to start
            'looking in the very first position in our collection (column 1 row 1). Initial position 0
            If NumberofRows = 1 Then
                RowData = LibraryMembersTableAdapter.GetDataByEmail(txtEmail.Text)(0)
                Password = RowData.Password 'this line of code grabs the password from our record. Password, our
                'variable, is an assignment statement. Column holds our password


                'Pseudocode: if the entered password matches, show form 2
                If Password = txtPassword.Text Then
                    verify = 1
                    txtEmail.Clear()
                    txtPassword.Clear()
                    frmMemberAccount.Show()
                    Me.Hide()
                    'MessageBox.Show("LOGIN SUCCESSFUL")
                    memberIDGlobal = RowData.MemberID
                    frmMemberAccount.RefreshTable()
                    frmSearch.btnMemberAccount.Visible = True

                Else
                    MessageBox.Show("LOGIN UNSUCCESSFUL") 'DISPLAY THE MESSAGE IF LOGIN WAS NOT SUCCESSFUL
                    txtPassword.Clear()
                End If
            Else
                MessageBox.Show("No record of this email registered. Please try a different email or register as a new user")

            End If
        End If

    End Sub


    Private Sub LibraryMembersBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.LibraryMembersBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database6DataSet)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database6DataSet.Checkout' table. You can move, or remove it, as needed.
        Me.CheckoutTableAdapter.Fill(Me.Database6DataSet.Checkout)
        'TODO: This line of code loads data into the 'Database6DataSet.LibraryResources' table. You can move, or remove it, as needed.
        Me.LibraryResourcesTableAdapter.Fill(Me.Database6DataSet.LibraryResources)
        'TODO: This line of code loads data into the 'Database6DataSet.Employee' table. You can move, or remove it, as needed.
        'Me.EmployeeTableAdapter.Fill(Me.Database6DataSet.Employee)
        'TODO: This line of code loads data into the 'Database6DataSet.LibraryMembers' table. You can move, or remove it, as needed.
        'Me.LibraryMembersTableAdapter.Fill(Me.Database6DataSet.LibraryMembers)

        'label color
        Me.DWYN.BackColor = Color.FromArgb(128, 0, 0, 0)
        'Me.Label3.BackColor = Color.FromArgb(128, 0, 0, 0)
        Me.Label4.BackColor = Color.FromArgb(140, 0, 0, 0)
    End Sub



    Private Sub lnkStaff_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lnkStaff.LinkClicked
        frmStaffLogin.Show()
        Me.Hide()
    End Sub

    Private Sub btnSignUp_Click(sender As Object, e As EventArgs) Handles btnSignUp.Click
        frmMSGctrl.Show()
        frmMSGctrl.Show_msg("HI THERE!", "Are you senior? If so, join us for Senior Saturdays!", frmMSGctrl.MessageType.Notice)
        txtEmail.Clear()
        txtPassword.Clear()
        frmRegistration.Show()
        Me.Hide()
    End Sub




 

  



    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        MessageBox.Show("Please Enter The Email Address You Used To Register and Associated Password")
    End Sub


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label5.Text = TimeOfDay
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label5_Click_1(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        'lblTitle.Visible = Not (lblTitle.Visible)

        Label6.Left += 5
        Label6.ForeColor = Color.DarkRed


        If Label6.Left > 900 Then
            Label6.Left = 0
        End If
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub


End Class





'Private Sub batSignUp_Click(sender As Object, e As EventArgs) Handles btnSignUp.Click
'frmMembership.Show()
'Me.Hide()
'End Sub

'Private Sub lnkStaff_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lnkStaff.LinkClicked
'frmStaffLogin.Show()
' Me.Hide()
'End Sub
'End Class
