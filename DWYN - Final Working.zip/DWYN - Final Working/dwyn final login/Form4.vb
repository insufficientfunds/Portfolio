﻿Public Class frmNewResource


    Private Sub frmNewResource_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' Me.BackColor = Color.FromArgb(128, 0, 0, 0)

    End Sub


    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim existingResource As Integer
        Dim subjects(6) As String


        Dim subject1 As String
        Dim subject2 As String
        Dim subject3 As String
        'Dim subject4 As String
        'Dim subject5 As String
        Dim x As Integer = 0
        Dim y As Integer = 0
        Dim NumberOfRowsResourceID As String
        Dim NumberOfRowsTitle As String

        'For Each i As Object In CheckedListBox1.CheckedItems
        'For Each i As Object In ChckedListBox1.CheckItems

        '    subjects(x) = i.ToString
        '    x += 1
        'Next


        'subject1 = subjects(0)
        'subject2 = subjects(1)
        'subject3 = subjects(2)
        'subject4 = subjects(3)
        'subject5 = subjects(4)
        'If String.IsNullOrEmpty(subject1) And String.IsNullOrEmpty(subject2) And String.IsNullOrEmpty(subject3) _
        '   And String.IsNullOrEmpty(subject4) And String.IsNullOrEmpty(subject5) Then
        '    MessageBox.Show("please select at least one subject area for this resource.")

        'Else
        '    If String.IsNullOrEmpty(subject1) Then
        '        subject1 = "--"
        '    End If

        '    If String.IsNullOrEmpty(subject2) Then
        '        subject2 = "--"
        '    End If

        '    If String.IsNullOrEmpty(subject3) Then
        '        subject3 = "--"
        '    End If
        'If String.IsNullOrEmpty(subject4) Then
        '    subject4 = "--"
        'End If
        'If String.IsNullOrEmpty(subject5) Then
        '    subject5 = "--"
        'End If

        'existingResource = LibraryResourcesTableAdapter.FillByResourceID(LibraryDataSet.LibraryResources, TxtResourceID.Text)
        'existingResource = LibraryResourcesTableAdapter.FillBySearchQuery(Database6DataSet.LibraryResources, TxtResourceID.Text)
        'existingResource = LibraryResourcesTableAdapter.FillDataBySearchQuery(Database6DataSet.LibraryResources, TxtResourceID.Text, TxtTitle.Text)

        existingResource = LibraryResourcesTableAdapter.FillBySearchQuery(Database6DataSet.LibraryResources, TxtResourceID.Text, TxtTitle.Text, TxtAuthorLast.Text)
        NumberOfRowsResourceID = LibraryResourcesTableAdapter.FillByResourceID(Database6DataSet.LibraryResources, TxtResourceID.Text)
        NumberOfRowsTitle = LibraryResourcesTableAdapter.FillByTitle(Database6DataSet.LibraryResources, TxtTitle.Text)

        If TxtResourceID.Text = String.Empty Then
            MessageBox.Show("Please enter a resource ID")
        ElseIf TxtResourceID.Text.Substring(0, 1) <> "b" Then
            MessageBox.Show("Resource ID must begin with the letter 'b'")
        ElseIf NumberOfRowsResourceID = 1 Then
            MessageBox.Show("This Resource ID already exists")
        ElseIf TxtSeries.Text = String.Empty Then
            MessageBox.Show("Please enter a book title")
        ElseIf NumberOfRowsTitle = 1 Then
            MessageBox.Show("This book title already exists")
        ElseIf TxtAuthorLast.Text = String.Empty Then
            MessageBox.Show("Please enter the author's last name")
        ElseIf TxtAuthorFirst.Text = String.Empty Then
            MessageBox.Show("Please enter the author's first name")
        ElseIf TxtPubDate.Text = String.Empty Then
            MessageBox.Show("Please enter a publication date")
        ElseIf CStr(IsNumeric(TxtPubDate.Text)) = False Then
            MessageBox.Show("Please enter the year only")
        ElseIf TxtSeries.Text = String.Empty Then
            MessageBox.Show("Please enter the series name")
        Else

            If existingResource = 0 Then
                LibraryResourcesTableAdapter.InsertNewResource(TxtResourceID.Text, TxtTitle.Text, TxtAuthorLast.Text, TxtAuthorFirst.Text, TxtPubDate.Text, TxtSeries.Text, subject1, subject2, subject3)
                MessageBox.Show("record successfully added")
                frmSearch.Show()
                Me.Close()
            Else
                MessageBox.Show("This resourceID has already been used for another library resource.  Please choose another ResourceID then click the Add New Resource button.")
                'hi

            End If
        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
        frmSearch.Show()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        'clear link
        TxtAuthorFirst.Text = ""
        TxtAuthorLast.Text = ""
        TxtPubDate.Text = ""
        TxtSeries.Text = ""
        TxtResourceID.Text = ""
        TxtTitle.Text = ""
    End Sub

    Private Sub TxtResourceID_TextChanged(sender As Object, e As EventArgs) Handles TxtResourceID.TextChanged

    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Me.Close()
        frmLOGIN.Show()
    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        MessageBox.Show("The 'X' characters could represent a series of books with a similar id; the 'Y' characters represents the copy # held in the collection")
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class

' Adding a query ask Dr A